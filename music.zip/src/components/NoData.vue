<template>
    <div class="no-data">
        <!-- vue简化开发 将template配置选项改为标签 -->
    </div>
</template>
<script>
export default {
    data() {
        return {
            
        }
    },
    methods: {
        
    },
    computed: {
        
    },
    watch: {
        
    },
    created() {
        
    }
}
</script>
<style lang="scss" scoped>
    
</style>